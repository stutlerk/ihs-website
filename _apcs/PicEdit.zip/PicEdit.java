import java.awt.*;

public class PicEdit {

   // returns a new Picture in which all pixels are shades of gray
   //
   // a color is transformed into a shade of gray by setting the red,
   //   green, and blue components to all be the average of the original
   //   components
   // that is, the new red, green, and blue are all set to:
   //   (red + green + blue) / 3
   public static Picture grayscale(Picture p) {
      return p;
   }

   // returns a new Picture that changes each pixel of p to be the "opposite" color
   //
   // two colors are opposites if their red, green, and blue values each 
   // add up to 255; that is: 
   //   color1.getRed() + color2.getRed() == 255 &&
   //   color1.getGreen() + color2.getGreen() == 255 &&
   //   color1.getBlue() + color2.getBlue() == 255
   public static Picture invertColors(Picture p) {
      return p;
   }
      
   // returns a new Picture with the contrast and brightness of p adjusted
   //
   // contrast and brightness are altered by applying the following formula
   //   to each color component of each pixel:
   //       contrAmt * (x - 128) + 128 + brightAmt
   //   where x is the original color component, contrAmt is the contrast modifier,
   //   and brightAmt is the brightness modifier
   // the final value for each color component must be in the range [0, 255]
   public static Picture changeContrastAndBrightness(Picture p, double contrAmt, double brightAmt) {
      return p;
   } 

   // returns a new Picture that results from running edge detection on p
   //
   // in the new image, pixels will all be either black or white
   // pixels on an "edge" (where the "color distance" is greater than
   //   threshold) will be black; all other pixels will be white
   // the "color distance" between to colors c1 and c2 is defined as the
   //   square root of:
   //     (c1.red - c2.red)^2 + (c1.green - c2.green)^2 + (c1.blue - c2.blue)^2
   public static Picture outline(Picture p, double threshold) {
      return p;
   }
   
   // returns a new Picture that reflects p 
   //
   // dir is one of 'h' (indicating a horizontal mirror) or 'v' (indicating a
   //   vertical mirror)
   public static Picture mirror(Picture p, char dir) {
      return p;
   }   
  
   // returns a new Picture that is a pixelated version of p
   //
   // to pixelate an image, each group of pixels up to radius away
   //   from a center pixel is set to the average of all pixels in the box
   // for example, if radius is 1, each of the nine pixels forming a box 
   //   centered at the original pixel is set to the average of all nine pixels
   // the average of a set of pixels is found by averaging the red, green,
   //   and blue components   
   public static Picture pixelate(Picture p, int radius) {
      return p;
   }


   // **EXTRA CREDIT**
   //
   // returns a new Picture that scales down the amount of a given color in p
   // 
   // color will be one of 'r', 'g', or 'b' indicating with color to scale
   // amt will have 0 <= amt <= 1.0 indicating the percent of the given color
   //   to remain
   // for example, if color is 'g' and amt is 0.75, then each pixel of the 
   //   Picture returned should have 75% as much green as that pixel of p
   public static Picture scaleColor(Picture p, char color, double amt) {
      return p;
   }
      
   // **EXTRA CREDIT**
   //
   // returns a new Picture that flips p 
   //
   // dir is one of 'h' (indicating a horizontal flip) or 'v' (indicating a
   //   vertical flip)
   public static Picture flip(Picture p, char dir) {
      return p;
   }

   // **EXTRA CREDIT**
   //
   // returns a new Picture in which a box blur has been run on p
   //
   // in a box blur, each pixel is set to the average of the pixels up 
   //   to radius pixels away from it (including the original pixel)
   // for example, if radius is 1, each pixel is set to the average of
   //   the nine pixels forming a box centered at the original pixel
   // the average of a set of pixels is found by averaging the red, green,
   //   and blue components
   public static Picture blur(Picture p, int radius) {
      return p;
   }   
}